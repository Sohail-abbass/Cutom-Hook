// import Usage from "./UseLocalStorage/Usage"
// import Responsive from "./UseMediaQuery/Responsive"
// import FormUsage from "./UseFormValidate/FormUsage"
// import DebounceUsage from "./UseDebounce/DebounceUsage"
// import PaginationUsage from "./UsePagination/PaginationUsage"
// import Usage from "./UseModal/Usage"
// import WebSocketChat from "./UseWebSocket/WebSocketChat"
// import GeoLocationComponent from "./UseGeoLocation/GeoLocationComponent"
// import DarkModeToggle from "./UseDarkMode/DarkModeToggle"
import KeyPressUsage from "./UsekeyPress/KeyPressUsage"
function App() {


  return (
    <>
     {/* <Responsive/> */}
     {/* <FormUsage/> */}
{/* <DebounceUsage/> */}
{/* <PaginationUsage/> */}
{/* <Usage/> */}
{/* <WebSocketChat/> */}
{/* <GeoLocationComponent/> */}
{/* <DarkModeToggle/> */}
<KeyPressUsage/>
    </>
  )
}

export default App
