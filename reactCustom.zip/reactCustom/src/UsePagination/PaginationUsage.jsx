// import React, { useState, useEffect } from 'react';
import usePagination from './usePagination';

const PaginationUsage = () => {
  const data = Array.from({ length: 100 }, (_, i) => `Item ${i + 1}`); 
//   [
//   "Item 1", "Item 2", "Item 3", "Item 4", ..., "Item 100"
// ]

  const { currentPage, totalPages, nextPage, previousPage, goToPage, pageData } = usePagination(data.length, 10);

  const handlePageChange = (event) => {
    goToPage(Number(event.target.value));
  };

  return (
    <div>
      <h2>Paginated List</h2>
      <ul>
        {pageData(data).map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>

      <div>
        <button onClick={previousPage} disabled={currentPage === 1}>
          Previous
        </button>
        <span>Page {currentPage} of {totalPages}</span>
        <button onClick={nextPage} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>

      <div>
        <input
          type="number"
          min="1"
          max={totalPages}
          value={currentPage}
          onChange={handlePageChange}
        />
      </div>
    </div>
  );
};

export default PaginationUsage;
