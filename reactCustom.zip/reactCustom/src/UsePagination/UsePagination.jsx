import { useState } from 'react';

const usePagination = (totalItems, itemsPerPage = 10) => {
  // Calculate total pages based on total items and items per page ciel is for round off
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  // State to track the current page
  const [currentPage, setCurrentPage] = useState(1);

  // Function to go to the next page
  const nextPage = () => {
    setCurrentPage((prevPage) => Math.min(prevPage + 1, totalPages));
  };

  // Function to go to the previous page
  const previousPage = () => {
    setCurrentPage((prevPage) => Math.max(prevPage - 1, 1));
  };

  // Function to go to a specific page
  const goToPage = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  // Calculate the data slice for the current page
  const pageData = (data) => {
    const start = (currentPage - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    return data.slice(start, end);
  };

  return {
    currentPage,
    totalPages,
    nextPage,
    previousPage,
    goToPage,
    pageData,
  };
};

export default usePagination;
