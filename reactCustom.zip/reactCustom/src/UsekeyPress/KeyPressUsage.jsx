import{ useState } from 'react';
import useKeyPress from './useKeyPress';

function KeyPressUsage() {
  const [count, setCount] = useState(0);

  useKeyPress('Enter', () => {
    setCount((prevCount) => prevCount + 1); 
  });


  useKeyPress('Escape', () => {
    setCount(0); // Reset count when Escape is pressed
  });

  return (
    <div>
      <p>Press enter to increment the count, escape to reset it.</p>
      <p>Current Count: {count}</p>
    </div>
  );
}

export default KeyPressUsage;
