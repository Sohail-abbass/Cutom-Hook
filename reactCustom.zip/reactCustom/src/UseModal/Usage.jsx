
import useModal from './UseModal';
function Usage() {
  const { isOpen, modalData, openModal, closeModal } = useModal();

  const openHandler = () => {
    // Passing data when opening the modal
    openModal({ message: 'Hello, I am Muhammad Sohail' });
  };

  return (
    <div>
      <button onClick={openHandler}>Open Modal</button>

      {isOpen && (
        <div  style={{ textAlign:"center",width:"50%",border:"3px solid black"}}className="modal">
       
            <p>{modalData ? modalData.message : 'No message'}</p>
            <button onClick={closeModal}>Close Modal</button>
          </div>
        
      )}
    </div>
  );
}

export default Usage;
