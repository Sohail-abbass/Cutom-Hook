import { useState, useEffect } from 'react';

/**

 */
const useMediaQuery = (query) => {
  const [match, setMatch] = useState(false);

  useEffect(() => {
    const mediaQueryList = window.matchMedia(query);

    const handleMatch = () => {
      setMatch(mediaQueryList.matches); // Correctly use 'matches'
    };

    handleMatch(); // Set initial state
    mediaQueryList.addEventListener('change', handleMatch); // Listen for changes

    // Cleanup listener on unmount
    return () => {
      mediaQueryList.removeEventListener('change', handleMatch);
    };
  }, [query]);

  return match;
};

export default useMediaQuery;
