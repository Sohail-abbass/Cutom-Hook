// import React from 'react';
import useMediaQuery from './useMediaQuery';

const Responsive = () => {
  const isSmallScreen = useMediaQuery('(max-width: 600px)');

  return (
    <div>
      {isSmallScreen ? (
        <p>You are on a small screen!</p>
      ) : (
        <p>You are on a large screen!</p>
      )}
    </div>
  );
};

export default Responsive;
