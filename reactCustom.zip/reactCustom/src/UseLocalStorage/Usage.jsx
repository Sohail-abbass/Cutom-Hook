// import React, { useState } from 'react';
import useLocalStorage from './useLocalStorage';

const Usage=()=> {
  const [name, setName] = useLocalStorage('name', 'Sohail Shigri'); // Using the custom hook

  return (
    <div>
      <h1>Welcome, {name}</h1>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)} // Updates state and localStorage
      />
    </div>
  );
}

export default Usage;
