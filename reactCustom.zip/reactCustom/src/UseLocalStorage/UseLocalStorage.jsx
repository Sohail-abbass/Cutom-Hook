import { useState, useEffect } from 'react';
// we make a logic to create own custom hook 
//  key and intialvalue are parameter and they are getting from usage.jsx
function useLocalStorage(key, initialValue) {
 
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      // Parse and return the item, or use initialValue if not found
      // to convert the JSON string back into its original data
     return item ? JSON.parse(item) : initialValue;
    //  const result=item ? JSON.parse(item) : initialValue;
      // console.log(result);
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return initialValue;
    }
  });  useEffect(() => {
    try {
      if (storedValue !== undefined) {
        // key are implicity converted into string and value are should to explicity convert into strong
        window.localStorage.setItem(key, JSON.stringify(storedValue));
      
      }
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [key, storedValue]); 

  return [storedValue, setStoredValue];
}

export default useLocalStorage;
