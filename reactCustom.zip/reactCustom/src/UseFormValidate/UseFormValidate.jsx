import { useState } from "react";

function useFormValidate(initialState, validate) {
  const [values, setValues] = useState(initialState);
//   take single state object to handle both email and passord error handle
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });

    // Validate the field as it's updated
    const error = validate({ ...values, [name]: value });
    setErrors({ ...errors, [name]: error[name] });
  };
  

  // Handle form submission
  const handleSubmit = (e, onSubmit) => {
    e.preventDefault();
    const validationErrors = validate(values);
    setErrors(validationErrors);

    // If no errors, submit the form
    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitting(true);
      onSubmit(values);
      setIsSubmitting(false);
    }
  };

  return {
    values,
    errors,
    isSubmitting,
    handleChange,
    handleSubmit,
  };
}

export default useFormValidate;
