import { useState, useEffect, useRef, useCallback } from 'react';

function useWebSocket(url) {
  const [messages, setMessages] = useState([]);
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef(null);

  useEffect(() => {
    socketRef.current = new WebSocket(url);

    socketRef.current.onopen = () => {
      setIsConnected(true); // WebSocket is connected
    };

    socketRef.current.onclose = () => {
      setIsConnected(false); // WebSocket is closed
    };

    socketRef.current.onmessage = (event) => {
      const newMessage = event.data;
    //   append the new mesage with the previous one
      setMessages((prevMessages) => [...prevMessages, newMessage]);
    };

    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [url]); 

  // Function to send messages
  const sendMessage = useCallback((message) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(message);
    }
  }, []);

  return {
    messages,
    isConnected,
    sendMessage,
  };
}

export default useWebSocket;
