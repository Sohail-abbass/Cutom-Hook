import  { useState } from 'react';
import useWebSocket from './UseWebSocket';

function WebSocketChat() {
  const { messages, isConnected, sendMessage } = useWebSocket('wss://example.com/socket');
  // i have not got the url
  const [messageInput, setMessageInput] = useState('');

  const handleSendMessage = () => {
    if (messageInput) {
      sendMessage(messageInput);
      setMessageInput(''); 
    }
  };

  return (
    <div>
      <h1>WebSocket Chat</h1>
      <div>
        <h2>Status: {isConnected ? 'Connected' : 'Disconnected'}</h2>
        <div>
          <h3>Messages</h3>
          <ul>
            {messages.map((msg, index) => (
              <li key={index}>{msg}</li>
            ))}
          </ul>
        </div>
      </div>
      <input
        type="text"
        value={messageInput}
        onChange={(e) => setMessageInput(e.target.value)}
        placeholder="Type a message"
      />
      <button onClick={handleSendMessage}>Send</button>
    </div>
  );
}

export default WebSocketChat;
