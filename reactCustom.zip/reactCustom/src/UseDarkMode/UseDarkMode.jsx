import { useState, useEffect } from 'react';

function useDarkMode() {
  // Check if the dark mode preference is already in localStorage, default to false if not
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Try to get the saved value from localStorage
    const savedPreference = localStorage.getItem('darkMode');
    // If it's not found in localStorage, default to 'false'
    return savedPreference ? JSON.parse(savedPreference) : false;
  });

  // Apply the theme (dark or light) to the document body
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Toggle dark mode and store the preference in localStorage
  const toggleDarkMode = () => {
    setIsDarkMode((prevMode) => {
      const newMode = !prevMode;
      localStorage.setItem('darkMode', JSON.stringify(newMode)); // Save preference in localStorage
      return newMode;
    });
  };

  return [isDarkMode, toggleDarkMode];
}

export default useDarkMode;
