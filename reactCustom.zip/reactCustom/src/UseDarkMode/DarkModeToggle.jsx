
import useDarkMode from './useDarkMode';

function DarkModeToggle() {
  const [isDarkMode, toggleDarkMode] = useDarkMode();
  const lightModeStyles = {
    backgroundColor: '#f0f0f0',
    color: 'black',
    padding: '10px',
    borderRadius: '5px',
    cursor: 'pointer',
  };

  const darkModeStyles = {
    backgroundColor: '#333',
    color: 'white',
    padding: '10px',
    borderRadius: '5px',
    cursor: 'pointer',
  };
  return (
    <div>
      <button  style={isDarkMode ? darkModeStyles : lightModeStyles} onClick={toggleDarkMode}>
        {isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      </button>
    </div>
  );
}

export default DarkModeToggle;
