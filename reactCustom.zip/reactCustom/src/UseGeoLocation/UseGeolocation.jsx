import { useState, useEffect } from 'react';

function useGeolocation() {
  const [location, setLocation] = useState({
    latitude: null,
    longitude: null,
    error: null,
  });

  useEffect(() => {
    const successFunction = (position) => {
      const { latitude, longitude } = position.coords;
      setLocation({ latitude, longitude, error: null });
    };

    const errorFunction = (error) => {
      setLocation({ latitude: null, longitude: null, error: error.message });
    };

  
    if (navigator.geolocation) {

      const watchId = navigator.geolocation.watchPosition(successFunction, errorFunction);

      // Cleanup function to stop watching position on unmount
      return () => {
        navigator.geolocation.clearWatch(watchId);
      };
    } else {
      setLocation({ latitude: null, longitude: null, error: 'Geolocation not supported' });
    }
  }, []);

  return location;
}

export default useGeolocation;
