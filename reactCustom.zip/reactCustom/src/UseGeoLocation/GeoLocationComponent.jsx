
import useGeolocation from './useGeolocation';

function GeolocationComponent() {
  const { latitude, longitude, error } = useGeolocation();

  return (
    <div>
      <h1>MY Geolocation</h1>
      {error ? (
        <p>Error: {error}</p>
      ) : (
        <p>
          Latitude of my Geo: {latitude ? latitude : 'Loading...'} <br />
          Longitude of my Geo: {longitude ? longitude : 'Loading...'}
        </p>
      )}
    </div>
  );
}

export default GeolocationComponent;
