import{ useState, useEffect } from "react";
import useDebounce from '/src/UseDebounce/UseDebounce.jsx';


const DebounceUsage = () => {
  const [query, setQuery] = useState("");
  const debouncedQuery = useDebounce(query, 500); // 500ms debounce

  useEffect(() => {
    if (debouncedQuery) {
      // Simulate an API call
      console.log("API Call with query:", debouncedQuery);
    }
  }, [debouncedQuery]);

  return (
    <div>
      <input
        type="text"
        placeholder="Search..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <p>Searching for: {debouncedQuery}</p>
    </div>
  );
};

export default DebounceUsage;
